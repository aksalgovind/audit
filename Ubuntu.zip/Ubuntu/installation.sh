sudo apt-get update -y
sudo apt update -y
sudo apt-get upgrade -y
sudo apt-get install vim -y
sudo atp-get install openvpn -y
sudo apt-get install openssh-sesrver
sudo apt autoremove -y
sudo apt-get install git -y
sudo apt-get install clamav
sudo apt-get install wget -y
sudo apt-get install curl -y
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt install ./google-chrome-stable_current_amd64.deb -y
wget https://download.teamviewer.com/download/linux/teamviewer_amd64.deb
sudo apt install ./teamviewer_amd64.deb -y
